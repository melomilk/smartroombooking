# Project memory

## Product intent & audience

- Booking-oriented application (scheduling/reservation logic with pure booking rules and fixture data).
- Audience and exact product scope not yet specified beyond booking functionality.

## Brand personality & voice

- Not yet inferred beyond `.bolt/prompt` direction (beautiful, production-worthy, non-cookie-cutter).

## Visual design & UX direction

- Built with Vite + React, JSX, Tailwind CSS, React hooks, and `lucide-react` icons.
- No UI theme/icon packages beyond the defaults.
- No design tokens, palette, typography, or layout patterns inferred yet.

## Decisions, constraints & rationale

- Stack: Vite + React + TypeScript + Tailwind CSS + lucide-react.
- Import alias: `@/` maps to `src/`.
- Scripts present: `npm test`, `npm run typecheck`, `npm run build`, `npm run lint`.
- Baseline test count: 11 passing.
- Booking rules are pure; fixture data is treated as immutable reference data.
- No auth, DB, server routes, secrets, unsafe HTML, dynamic code, or unsafe redirects — frontend-only app.
- Known lint debt: unused imports and an unused `duration` value in `src/App.tsx` (3 unused-code errors).

## Open questions & assumptions

- Exact product name, target audience, and booking domain (rooms, events, services?) unknown.
- No README and no Git history exist; documentation and version control practices not established.
- Whether lint failures are meant to be fixed in a future task or intentionally left is unresolved.